set define off
begin
       dbms_aqadm.create_queue_table(
          queue_table        => 'nab_realtime_ops_table', 
          queue_payload_type => 'sys.aq$_jms_map_message',
          multiple_consumers => true);
          
       dbms_aqadm.create_queue(
          queue_name  => 'nab_realtime_ops',
          queue_table => 'nab_realtime_ops_table');
          
       dbms_aqadm.start_queue(queue_name => 'nab_realtime_ops');
    
       dbms_aqadm.create_queue_table(
          queue_table        => 'nab_status_table', 
          queue_payload_type => 'sys.aq$_jms_map_message',
          multiple_consumers => true);
          
       dbms_aqadm.create_queue(
          queue_name  => 'nab_status',
          queue_table => 'nab_status_table');
          
       dbms_aqadm.start_queue(queue_name => 'nab_status');
    
       dbms_aqadm.create_queue_table(
          queue_table        => 'nab_ts_stored_table', 
          queue_payload_type => 'sys.aq$_jms_map_message',
          multiple_consumers => true);
          
       dbms_aqadm.create_queue(
          queue_name  => 'nab_ts_stored',
          queue_table => 'nab_ts_stored_table');
          
       dbms_aqadm.start_queue(queue_name => 'nab_ts_stored');
    end;
/
commit;
