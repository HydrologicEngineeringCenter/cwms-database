set echo off
set time on
set define on
set concat on
set linesize 1024   
whenever sqlerror exit sql.sqlcode

define echo_state = ON
define inst = V11203CWMSDV
define sys_passwd = cwmsdevdb
define cwms_schema = CWMS_20
define cwms_passwd = cwmsdevdb
define dbi_passwd = cwmsdevdb
define test_passwd = cwmsdevdb
 
spool buildCWMS_DB.log
--
-- log on as sysdba
--
connect sys/&sys_passwd@&inst as sysdba
--ALTER SYSTEM ENABLE RESTRICTED SESSION;
--
--
select sysdate from dual;
set serveroutput on
begin dbms_output.enable; end;
/
set echo &echo_state
--
-- create user roles and users
--
@@cwms/User-Roles/cwms_user_profile
@@cwms/User-Roles/cwms_user_roles
@@cwms/User-Roles/cwms_users
@@cwms/User-Roles/cwms_dba_user

--
@@cwms_dba/cwms_user_admin_pkg
@@cwms_dba/cwms_user_admin_pkg_body
--
set define on
grant execute on  cwms_dba.cwms_user_admin to &cwms_schema;
grant execute on  dbms_crypto to cwms_user;

--
-- switch to cwms_schema 
--
alter session set current_schema = &cwms_schema;

--
-- structure that can be built without the CWMS API,
-- even if it results in invalid objects
--
@@py_BuildCwms
@@cwms/cwms_types
@@cwms/at_schema
@@cwms/at_schema_crrel
@@cwms/at_schema_shef
@@cwms/at_schema_alarm
@@cwms/at_schema_screening
@@cwms/at_schema_dss_xchg
@@cwms/at_schema_msg
@@cwms/at_schema_at_data
@@cwms/at_schema_mv
@@cwms/at_schema_av
@@cwms/at_schema_rating
@@cwms/at_schema_tsv
@@cwms/at_schema_tr
@@cwms/at_schema_sec_2
@@cwms/at_schema_sec
@@cwms/at_schema_apex_debug

--
--  Load data into cwms tables...
--
@@data/cwms_shef_pe_codes
@@data/cwms_schema_object_version


--
-- CWMS API
--
@@cwms/api
-- Context needs to be created after the package is created
@@cwms/at_schema_env

--
-- structure that can't be built without the CWMS API,
-- 
@@cwms/at_schema_2
@@cwms/at_schema_tsv_dqu
@@cwms/at_schema_mv2
--@@cwms/cwms_types_rating
--
-- Create dbi and pd user accounts...
---
set define on
@@py_ErocUsers

--
-- Create public synonyms and cwms_user roles
@@cwms/at_schema_public_interface.sql

--
-- compile all invalid objects
--
SET define on
alter materialized view "&cwms_schema"."MV_SEC_TS_PRIVILEGES" compile
/

set echo off
prompt Invalid objects...
  select substr(object_name, 1, 31) "INVALID OBJECT", object_type 
    from dba_objects 
   where owner = '&cwms_schema' 
     and status = 'INVALID'
order by object_name, object_type asc;

prompt Recompiling all invalid objects...
exec utl_recomp.recomp_serial('&cwms_schema');
/

prompt Remaining invalid objects...
  select substr(object_name, 1, 31) "INVALID OBJECT", object_type 
    from dba_objects 
   where owner = '&cwms_schema' 
     and status = 'INVALID'
order by object_name, object_type asc;

declare
   obj_count integer;
begin
   select count(*)
     into obj_count
     from dba_objects
    where owner = '&cwms_schema' 
      and status = 'INVALID';
   if obj_count > 0 then
      dbms_output.put_line('' || obj_count || ' objects are still invalid.');
      raise_application_error(-20999, 'Some objects are still invalid.');
   else
      dbms_output.put_line('All invalid objects successfully compiled.');
   end if;
end;
/

-- set COMPATIBLE parameter
alter system set compatible='11.2.0' scope=spfile;

-- Create CWMS_DBXC_ROLE

@@cwms/User-Roles/cwms_dbx_role_et_user

set echo off
--
-- log on as the CWMS schema user and start queues and jobs
--
--ALTER SYSTEM DISABLE RESTRICTED SESSION;
--EXEC DBMS_LOCK.SLEEP(1);

set define on
prompt Connecting as &cwms_schema
connect &cwms_schema/&cwms_passwd@&inst
set serveroutput on
prompt Connected as &cwms_schema
--------------------------------
-- populate base data via API --
--------------------------------
begin
   cwms_text.store_std_text('A', 'NO RECORD');
   cwms_text.store_std_text('B', 'CHANNEL DRY');
   cwms_text.store_std_text('C', 'POOL STAGE');
   cwms_text.store_std_text('D', 'AFFECTED BY WIND');
   cwms_text.store_std_text('E', 'ESTIMATED');
   cwms_text.store_std_text('F', 'NOT AT STATED TIME');
   cwms_text.store_std_text('G', 'GATES CLOSED');
   cwms_text.store_std_text('H', 'PEAK STAGE');
   cwms_text.store_std_text('I', 'ICE/SHORE ICE');
   cwms_text.store_std_text('J', 'INTAKES OUT OF WATER');
   cwms_text.store_std_text('K', 'FLOAT FROZEN/FLOATING ICE');
   cwms_text.store_std_text('L', 'GAGE FROZEN');
   cwms_text.store_std_text('M', 'MALFUNCTION');
   cwms_text.store_std_text('N', 'MEAN STAGE FOR THE DAY');
   cwms_text.store_std_text('O', 'OBSERVERS READING');
   cwms_text.store_std_text('P', 'INTERPOLATED');
   cwms_text.store_std_text('Q', 'DISCHARGE MISSING');
   cwms_text.store_std_text('R', 'HIGH WATER, NO ACCESS');
end;
/
--------------------------------------
-- create and start queues and jobs --
--------------------------------------
prompt Creating and starting queues...
@py_Queues
prompt Starting jobs...
begin
   cwms_msg.start_trim_log_job;
   cwms_msg.start_purge_queues_job;
   cwms_schema.cleanup_schema_version_table;
   cwms_schema.start_check_schema_job;
   cwms_ts.start_trim_ts_deleted_job;
   cwms_sec.start_refresh_mv_sec_privs_job;
   cwms_shef.start_update_shef_spec_map_job;
   cwms_rating.start_update_mviews_job;
end;
/
--
-- all done
--
exit 0

