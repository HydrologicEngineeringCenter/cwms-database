CREATE OR REPLACE PACKAGE zz_utils AS
/******************************************************************************
   NAME:       zz_utils
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        11/3/2008             1. Created this package.
******************************************************************************/


  PROCEDURE load_cwms_shef_pe_codes;

END zz_utils;

/
