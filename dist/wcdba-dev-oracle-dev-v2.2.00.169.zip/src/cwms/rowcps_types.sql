WHENEVER sqlerror EXIT sql.sqlcode
SET define ON
@@../cwms/defines.sql
SET serveroutput ON
--
--
--
--location objects are defined in cwms_types.
--location_ref_t and location_obj_t.
CREATE OR REPLACE TYPE lookup_type_obj_t
/**
 * Holds data from one of several similarly-structured tables in the database.
 * Primarily used to hold brief names and descriptions for REGI/ROWCPS application.
 *
 * @see type lookup_table_tab_t
 *
 * @member office_id     The office that owns the information
 * @member display_value The brief name or identifier
 * @member tooltip       The longer description, often targeted for a tooltip
 * @member active        A flag ('T' or 'F') that specifies whether this item is active
 */
AS
  OBJECT
  (
    office_id     VARCHAR2 (16),      -- the office id for this lookup type
    display_value VARCHAR2(25 byte),  --The value to display for this lookup record
    tooltip       VARCHAR2(255 byte), --The tooltip or meaning of this lookup record
    active        VARCHAR2(1 byte)    --Whether this lookup record entry is currently active
  );
  /
  show errors
  --
  --
  --
CREATE OR REPLACE TYPE lookup_type_tab_t
/**
 * Holds a collection of lookup_type_obj_t objects
 *
 * @see type lookup_type_obj_t
 */
IS
  TABLE OF lookup_type_obj_t;
  /
  show errors
  --
  --
  --
CREATE OR REPLACE TYPE document_obj_t
/**
 * Holds a document identifier
 *
 * @see type document_tab_t
 *
 * @member office_id   The office that owns the document
 * @member document_id The document identifier
 */
AS
  OBJECT
  (
    office_id   VARCHAR2 (16),    -- the office id for this lookup type
    document_id VARCHAR2(64 BYTE) -- The unique identifier for the individual document, user provided
  );
  /
  show errors
  --
  --
  --
CREATE OR REPLACE TYPE document_tab_t
/**
 * Holds a collection of document identifiers
 *
 * @see type document_obj_t
 */
IS
  TABLE OF document_obj_t;
  /
  show errors
  --project object.
  --
  --
  --
CREATE OR REPLACE TYPE project_obj_t
/**
 * Holds information about a CWMS project
 *
 * @member project_location               Location identifier of project
 * @member pump_back_location             Location identifier of pump-back to this project, if any
 * @member near_gage_location             Location identifier of the nearest gage to the project
 * @member authorizing_law                The law that authorized construction of the project
 * @member cost_year                      Year that costs are indexed to
 * @member federal_cost                   Federal cost to construct the project
 * @member nonfederal_cost                Non-federal cost to construct the project
 * @member federal_om_cost                Federal cost of annual operation and maintenance
 * @member nonfederal_om_cost             Non-federal cost of annual operation and maintenance
 * @member cost_units_id                  Unit of costs
 * @member remarks                        General remarks about project
 * @member project_owner                  Owner of the project
 * @member hydropower_description         Description of the hydopower at this project, if applicable
 * @member sedimentation_description      Description of the sedimentation at this project, if applicable
 * @member downstream_urban_description   Description of urbanization downstream of this project, if applicable
 * @member bank_full_capacity_description Description of the bank-full capacity at th is project, if applicable
 * @member yield_time_frame_start         Beginning of time window for critical period for this project
 * @member yield_time_frame_end           End of time window for critical period for this project
 */
AS
  OBJECT
  (
  
    --locations
    --the location associated with this project,
    --an instance of the location type.
    --has the db office id for this project.
    project_location location_obj_t,
    --The location code where the water is pumped back to
    pump_back_location location_obj_t,
    --The location code known as the near gage for the project
    near_gage_location location_obj_t,
    --The law authorizing this project
    authorizing_law VARCHAR2(32),
    --The year the project cost data is from
    cost_year DATE,
    federal_cost       NUMBER, --Param: Currency. The federal cost of this project
    nonfederal_cost    NUMBER, --Param: Currency. The non-federal cost of this project
    federal_om_cost    NUMBER, --Param: Currency. The om federal cost of this project
    nonfederal_om_cost NUMBER, --Param: Currency. the non-federal cost of this project
    -- the units id of the cost fields.
    cost_units_id VARCHAR2(16),
    --The general remarks regarding this project
    --Should this be a  CLOB?
    remarks VARCHAR2(1000),
    --The assigned owner of this project
    project_owner VARCHAR2(255),
    --The description of the hydro-power located at this project
    hydropower_description VARCHAR2(255),
    --The description of the projects sedimentation
    sedimentation_description VARCHAR(255),
    --The description of the urban area downstream
    downstream_urban_description VARCHAR(255),
    --The description of the full capacity
    bank_full_capacity_description VARCHAR(255),
    --The start date of the yield time frame
    yield_time_frame_start DATE,
    --The end date of the yield time frame
    yield_time_frame_end DATE );
  /
  show errors
  --
  --
  --
CREATE OR REPLACE TYPE embankment_obj_t
  /**
   * Holds information about an embankment at a CWMS project
   *
   * @see type embankment_tab_t
   *
   * @member project_location_ref Identifies the CWMS project
   * @member embankment_location  Location information about the embankment
   * @member structure_type       The type of the embankment structure
   * @member upstream_prot_type   The type of upstream protection of the embankment
   * @member downstream_prot_type The type of downstream protection of the embankment
   * @member upstream_sideslope   The slope of the upstream side of the embankment
   * @member downstream_sideslope The slope of the downstream side of the embankment
   * @member structure_length     The length of the embankment
   * @member height_max           The maximum height of the embankment
   * @member top_width            The top width of the embankment
   * @member units_id             The unit of length, height, and width
   */
AS
  OBJECT
  (
    project_location_ref location_ref_t,    --The project this embankment is a child of
    embankment_location location_obj_t,     --The location for this embankment
    structure_type lookup_type_obj_t,       --The lookup code for the type of the embankment structure
    upstream_prot_type lookup_type_obj_t,   --The upstream protection type code for the embankment structure
    downstream_prot_type lookup_type_obj_t, --The downstream protection type codefor the embankment structure
    upstream_sideslope BINARY_DOUBLE,       --Param: ??. The upstream side slope of the embankment structure
    downstream_sideslope BINARY_DOUBLE,     --Param: ??. The downstream side slope of the embankment structure
    structure_length BINARY_DOUBLE,         --Param: Length. The overall length of the embankment structure
    height_max BINARY_DOUBLE,               --Param: Height. The maximum height of the embankment structure
    top_width BINARY_DOUBLE,                --Param: Width. The width at the top of the embankment structure
    units_id VARCHAR2(16)                   --The units id of the lenght, width, and height values
  );
  /
  show errors
  --
  --
  --
CREATE OR REPLACE TYPE embankment_tab_t
/**
 * Holds a collection of embankment_obj_t objects
 *
 * @see type embankment_obj_t
 */
IS
  TABLE OF embankment_obj_t;
  /
  show errors
  --
  --
  --
CREATE OR REPLACE TYPE water_user_obj_t
/**
 * Holds information about a water user for a CWMS project
 *
 * @see type water_user_tab_t
 *
 * @member project_location_ref Identifies the CWMS project
 * @member entity_name          The name of the water user
 * @member water_right          The water right for the water user at this project
 */
AS
  OBJECT
  (
    project_location_ref location_ref_t, --The project that this user is pertaining to.
    entity_name VARCHAR2(64 BYTE),       --The entity name associated with this user
    water_right VARCHAR2(255 BYTE)       --The water right of this user (optional)
  );
  /
  show errors
  --
  --
  --
CREATE OR REPLACE TYPE water_user_tab_t
/**
 * Hold a collection of water_user_obj_t objects
 *
 * @see type water_uer_obj_t
 */
IS
  TABLE OF water_user_obj_t;
  /
  show errors
  --
  --
  --
CREATE OR REPLACE TYPE water_user_contract_ref_t
/**
 * Holds minimal information about a water user contract
 *
 * @see water_user_contract_obj_t
 *
 * @member water_user    The water user
 * @member contract_name The identifier for the water user contract
 */
AS
  OBJECT
  (
    water_user water_user_obj_t,   --The water user this record pertains to.  See table AT_WATER_USER.
    contract_name VARCHAR2(64 BYTE)--The identification name for the contract for this water user contract
  );
  /
  show errors
  --
  --
  --
CREATE OR REPLACE type water_user_contract_obj_t
/**
 * Holds information about a water user contract
 *
 * @see type water_user_contract_ref_t
 * @see type water_user_contract_tab_t
 *
 * @member water_user_contract_ref       Identifies the water user and contract
 * @member water_supply_contract_type    The type of water supply contract
 * @member ws_contract_effective_date    The effective date of the contract
 * @member ws_contract_expiration_date   The expiration date of the contract
 * @member contracted_storage            The storage under contract
 * @member initial_use_allocation        The initial storage allocation for this contract
 * @member future_use_allocation         The future storage allocation for this contract
 * @member storage_units_id              The unit for storage
 * @member future_use_percent_activated  The percentage of the future storage allocation that has been utilized
 * @member total_alloc_percent_activated The percentage of the total storage allocation that has been utilized
 * @member pump_out_location             The location where water is withrawn from the project, if any
 * @member pump_out_below_location       The location where water is withdrawn below the project, if any
 * @member pump_in_location              The location where water is pumped in to the project, if any
 */
AS
  object
  (
    water_user_contract_ref water_user_contract_ref_t,
    -- contract_documents VARCHAR2(64 BYTE),--The documents for the contract
    water_supply_contract_type lookup_type_obj_t, -- The type of water supply contract. FK'ed to a LU table.
    ws_contract_effective_date DATE,              --The start date of the contract for this water user contract
    ws_contract_expiration_date DATE,             --The expiration date for the contract of this water user contract
    contracted_storage BINARY_DOUBLE,             --Param: Stor. The contracted storage amount for this water user contract
    initial_use_allocation BINARY_DOUBLE,         --Param: Stor. The initial contracted allocation for this water user contract
    future_use_allocation BINARY_DOUBLE,          --Param: Stor. The future contracted allocation for this water user contract
    storage_units_id VARCHAR2(15),                -- the units used for contracted storage and allocations.
    future_use_percent_activated BINARY_DOUBLE,   --Param: ??. The percent allocated future use for this water user contract
    total_alloc_percent_activated BINARY_DOUBLE,  --Param: ??. The percentage of total allocation for this water user contract
    pump_out_location location_obj_t,             -- used to be withdrawal
    pump_out_below_location location_obj_t,       -- used to be supply
    pump_in_location location_obj_t               
  );
  /
  show errors
  --
  --
  --
CREATE OR REPLACE TYPE water_user_contract_tab_t
/**
 * Holds a collection of water_user_contract_obj_t objects
 *
 * @see type water_user_contract_obj_t
 */
IS
  TABLE OF water_user_contract_obj_t;
  /
  show errors
  --
  --
  --
CREATE OR REPLACE type wat_usr_contract_acct_obj_t
/**
 * Holds a water user contract accounting record
 *
 * @see type wat_usr_contract_acct_tab_t
 *
 * @member water_user_contract_ref Identifies the water user contract
 * @member pump_location_ref       The location of the pump for this accounting record
 * @member physical_transfer_type  Identifies the type of water transfer for this accounting record
 * @member pump_flow               The pump flow for this accounting record
 * @member transfer_start_datetime The beginning time for the water transfer for this accounting record
 * @member accounting_remarks      Remarks for this accounting record
 */
AS
  object
  (
    water_user_contract_ref water_user_contract_ref_t,--The contract for this water movement. SEE AT_WATER_USER_CONTRACT.
    pump_location_ref location_ref_t, --the contract pump that was used for this accounting.
    physical_transfer_type lookup_type_obj_t,         --The type of transfer for this water movement.  See AT_PHYSICAL_TRANSFER_TYPE_CODE.
    pump_flow binary_double,                  --Param: Flow. The flow associated with the water accounting record
    transfer_start_datetime date,                     --The date this water movement began, DATE includes the time zone.
    accounting_remarks varchar2(255 byte)             --Any comments regarding this water accounting movement
  );
  /
  show errors
  --
  --
  --
CREATE OR REPLACE TYPE wat_usr_contract_acct_tab_t
/**
 * Holds a collection of water user accounting records
 */
IS
  TABLE OF wat_usr_contract_acct_obj_t;
  /
  show errors
  
CREATE OR REPLACE type loc_ref_time_window_obj_t
/**
 * Holds a time window for a location
 *
 * @see type loc_ref_time_window_tab_t
 *
 * @member location_ref Identifies the location
 * @member start_date   The beginning of the time window
 * @member end_dete     The end of the time window
 */
AS
  object
  (
    location_ref location_ref_t, 
    start_date DATE,
    end_date DATE
    );
/
show errors

CREATE OR REPLACE TYPE loc_ref_time_window_tab_t
/**
 * Holds a collection of location time windows
 */
IS
  TABLE OF loc_ref_time_window_obj_t;
  /
  show errors


  --
  --
  --
CREATE OR REPLACE TYPE lock_obj_t
/**
 * Holds information about a lock at a CWMS project
 *
 * @member project_location_ref Identifies the CWMS project
 * @member lock_location        The location information about the locak
 * @member volume_per_lockage   The volume of water released for each lockage
 * @member volume_units_id      The unit for lockage volume
 * @member lock_width           The width of the lock
 * @member lock_length          The length of the lock
 * @member minimum_draft        The minimum draft for the lock
 * @member normal_lock_lift     The elevation difference between upstream and downstream pools
 * @member units_id             The unit of length, width, draft, and lift
 */
AS
  OBJECT
  (
    project_location_ref location_ref_t, --The project this embankment is a child of
    lock_location location_obj_t,        --The location for this embankment
    -- the volume of water discharged for one lockage at
    --normal headwater and tailwater elevations.  this volume includes any flushing water.
    volume_per_lockage binary_double, -- Param: Stor.
    volume_units_id VARCHAR2(16),     -- the units of the volume value.
    lock_width binary_double,         -- Param: Width. The width of the lock chamber
    lock_length binary_double,        -- Param: Length. the length of the lock chamber
    minimum_draft binary_double,      -- Param: Depth. the minimum depth of water that is maintained for vessels for this particular lock
    normal_lock_lift binary_double,   -- Param: Height. The difference between upstream pool and downstream pool at normal elevation.
    units_id VARCHAR2(16)             -- the units id used for width, length, draft, and lift.
  );
  /
  show errors
  --
  --
  --
CREATE OR REPLACE TYPE characteristic_ref_t
/**
 * Identifies a characteristic
 *
 * @member office_id         The office that owns the characteristic
 * @member characteristic_id The characteristic identifier
 */
AS
  OBJECT
  (
    office_id         VARCHAR2 (16), -- the office id for this ref
    characteristic_id VARCHAR2 (64)  -- the id of this characteristic.
  );
  /
  show errors
  --
  --
  --
CREATE OR REPLACE TYPE project_structure_obj_t
/**
 * Holds information about a structure at a CWMS project
 *
 * @see type project_structure_tab_t
 *
 * @member project_location_ref Identifies the project
 * @member structure_location   The location information about structure
 * @member characteristic_ref   Identifies the characteristic
 */
AS
  OBJECT
  (
    project_location_ref location_ref_t,           --The project this structure is a child of
    structure_location location_obj_t,                  --The location for this structure
    characteristic_ref characteristic_ref_t   -- the characteristic for this structure.
  );
  /
  show errors
  --
  --
  --
CREATE OR REPLACE TYPE project_structure_tab_t
/**
 * Holds a collection of project_structure_obj_t objects
 *
 * @see type project_structure_obj_t
 */
IS
  TABLE OF project_structure_obj_t;
  /
  show errors
  --
  --
  --
CREATE OR REPLACE TYPE characteristic_obj_t
/**
 * Holds information about a characteristic
 *
 * @see type characteristic_ref_t
 * @see type characteristic_tab_t
 *
 * @member characteristic_ref  Identifies the characteristic
 * @member general_description Describes the characteristic
 */
AS
  OBJECT
  (
    characteristic_ref characteristic_ref_t, -- office id and characteristic id
--    opening_parameter_id VARCHAR2 (16),             -- A foreign key to an AT_PARAMETER record that constrains the gate opening to a defined parameter and unit.
--    height BINARY_DOUBLE,                           -- The height of the gate
--    width binary_double,                            -- The width of the gate
--    opening_radius binary_double,                   -- The radius of the pipe or circular conduit that this outlet is a control for.  This is not applicable to rectangular outlets, tainter gates, or uncontrolled spillways
--    opening_units_id VARCHAR2(16),                  -- the units of the opening radius value.
--    elev_invert binary_double,                      -- The elevation of the invert for the outlet
--    flow_capacity_max BINARY_DOUBLE,                --  The maximum flow capacity of the gate
--    flow_units_id VARCHAR2(16),                     -- the units of the flow value.
--    net_length_spillway binary_double,              -- The net length of the spillway
--    spillway_notch_length binary_double,            -- The length of the spillway notch
--    length_units_id            VARCHAR2(16),                   -- the units of the height, width, and length.
    general_description VARCHAR2(255)                   -- description of the outlet characteristic
  );
  /
  show errors
  --
  --
  --
CREATE OR REPLACE TYPE characteristic_tab_t
/**
 * Holds a table of characteristics
 *
 * @see type characteristic_obj_t
 */
IS
  TABLE OF characteristic_obj_t;
  /
  show errors
--
-- gate calc
-- 
CREATE OR REPLACE type gate_setting_obj_t
/**
 * Holds information about a gate setting
 *
 * @see type gate_setting_tab_t
 * @see type gate_change_obj_t
 *
 * @member outlet_location_ref Identifies the gate
 * @member opening             The opening value
 * @member opening_parameter   The opening parameter
 * @member opening_units       The opening unit
 */
AS
  object
  (
  --required
  outlet_location_ref location_ref_t,
  opening binary_double,
  opening_parameter varchar2(49),
  opening_units varchar2(16)
  );
  /
  show errors
  --
CREATE OR REPLACE TYPE gate_setting_tab_t
/**
 * Holds a collection of gate settings
 *
 * @see type gate_setting_obj_t
 * @see type gate_change_obj_t
 */
is
  TABLE OF gate_setting_obj_t;
  /
  show errors
--
--
CREATE OR REPLACE type gate_change_obj_t
/**
 * Holds information about a gate change at a CWMS project
 *
 * @see type gate_change_tab_t
 *
 * @member project_location_ref         Identifies the project
 * @member change_date                  The date/time of the gate change
 * @member elev_pool                    The pool elevation at the time of the gate change
 * @member discharge_computation        The type of discharge computation used
 * @member release_reason               The reason for the gate change
 * @member settings                     Settings of individual gates
 * @member elev_tailwater               The tailwater elevation at the time of the gate change
 * @member elev_units                   The elevation unit
 * @member old_total_discharge_override The discharge before the gate change
 * @member new_total_discharge_override The discharge after the gate change
 * @member discharge_units              The discharge unit
 * @member change_notes                 Notes about the gate change
 * @member protected                    A flag ('T' or 'F') specifying whether this gate change is protected from future updates
 */
AS
  object
  (
      --required
      project_location_ref location_ref_t, --PROJECT_LOCATION_CODE
      change_date date, --GATE_CHANGE_DATE
      elev_pool binary_double, --ELEV_POOL
      discharge_computation lookup_type_obj_t, --DISCHARGE_COMPUTATION_CODE
      release_reason lookup_type_obj_t, --release_reason_code
      settings gate_setting_tab_t,
      --not required
      elev_tailwater binary_double, --ELEV_TAILWATER
      elev_units varchar2(16), 
      old_total_discharge_override binary_double, --OLD_TOTAL_DISCHARGE_OVERRIDE
      new_total_discharge_override binary_double, --NEW_TOTAL_DISCHARGE_OVERRIDE
      discharge_units  varchar2(16), 
      change_notes VARCHAR2(255 BYTE), --GATE_CHANGE_NOTES
      protected varchar2(1) --PROTECTED_FLAG
);
  /
  show errors
  --
  --
  --
CREATE OR REPLACE TYPE gate_change_tab_t
/**
 * Holds information on a collection of gate changes
 *
 * @see type gate_change_obj_t
 */
is
  TABLE OF gate_change_obj_t;
  /
  show errors
  
--
-- turbines
--
CREATE OR REPLACE
type TURBINE_SETTING_OBJ_T
AS
/**
 * Holds information about a turbine setting at a CWMS project
 *
 * @see type turbine_setting_tab_t
 * @see type turbine_change_obj_t
 *
 * @member turbine_location_ref Identifies the turbine
 * @member old_discharge        The discharge through the turbine before the setting
 * @member new_discharge        The discharge through the turbine after the setting
 * @member discharge_units      The discharge unit
 * @member real_power           The actual power generated by the turbine after the setting
 * @member scheduled_load       The scheduled load for the turbine at the time of the setting
 * @member generation_units     The unit of power generation and load
 */
  object
  (
  --required
  turbine_location_ref location_ref_t,
  old_discharge binary_double,
  new_discharge binary_double,
  --setting lookup?
  --discharge lookup?

  --not required
  discharge_units varchar2(16),
  real_power binary_double,
  scheduled_load binary_double,
  generation_units varchar2(16)
);
/
  show errors
  --
CREATE OR REPLACE TYPE turbine_setting_tab_t
/**
 * Holds information about a collection of turbine settings
 *
 * @see type turbine_setting_obj_t
 * @see type turbine_change_obj_t
 */
is
  TABLE OF turbine_setting_obj_t;
  /
  show errors
--
--
CREATE OR REPLACE type turbine_change_obj_t
/**
 * Holds information about a turbine change at a CWMS project
 *
 * @see type tubine_change_tab_t
 *
 * @member project_location_ref         Identifies the project
 * @member change_date                  The date/time of the turbine change
 * @member discharge_computation        The discharge computation used for the turbine change
 * @member setting_reason               The reason for the turbine change
 * @member settings                     The individual turbine settings
 * @member elev_pool                    The pool elevation at the time of the turbine change
 * @member elev_tailwater               The tailwater elevation at the time of the turbine change
 * @member elev_units                   The elevation unit
 * @member old_total_discharge_override The total discharge before the turbine change
 * @member new_total_discharge_override The total discharge after the turbine change
 * @member discharge_units              The discharge unit
 * @member change_notes                 Notes about the turbine change
 * @member protected                    A flag ('T' or 'F') specifying whether the turbine change is protected from future updates
 */
AS
  object
  (
      --required
      project_location_ref location_ref_t, --PROJECT_LOCATION_CODE
      change_date date, --xxx_CHANGE_DATE
      
      discharge_computation lookup_type_obj_t, --turbine_discharge_comp_code
      setting_reason lookup_type_obj_t, --turbine_setting_reason_code
      
      settings turbine_setting_tab_t,
      --not required 
      elev_pool binary_double,
      elev_tailwater binary_double,
      elev_units varchar2(16),
      old_total_discharge_override binary_double, --OLD_TOTAL_DISCHARGE_OVERRIDE
      new_total_discharge_override binary_double, --NEW_TOTAL_DISCHARGE_OVERRIDE
      discharge_units  varchar2(16), 
      change_notes VARCHAR2(255 BYTE), --GATE_CHANGE_NOTES
      protected varchar2(1) --PROTECTED_FLAG
);
  /
  show errors
  --
  --
  --
CREATE OR REPLACE TYPE turbine_change_tab_t
/**
 * Holds a collection of turbine changes
 *
 * @see type turbine_change_obj_t
 */
is
  TABLE OF turbine_change_obj_t;
  /
  show errors
/*
--
--
SET echo ON
--
-- create public synonyms for CWMS schema types
-- grant execute on types to CWMS_USER role
--
declare
   type str_tab_t is table of varchar2(32);
   l_type_names str_tab_t;
   l_synonym    varchar2(32);
   l_existing   varchar2(32);
   l_sql        varchar2(256);
begin
   -----------------------
   -- collect the types --
   -----------------------
   select type_name
          bulk collect
     into l_type_names
     from dba_types
    where owner='CWMS_21'
      and type_name not like 'SYS\_%' escape '\'
 order by type_name;
   ----------------------------------------------
   -- grant execute on types to CWMS user role --
   ----------------------------------------------
   for i in 1..l_type_names.count loop
      l_sql := 'grant execute on &cwms_schema..'||l_type_names(i)||' to cwms_user';
      dbms_output.put_line('-- '||l_sql);
      execute immediate l_sql;
   end loop;
   --------------------------------------
   -- create public synonyms for types --
   --------------------------------------
   for i in 1..l_type_names.count loop
      l_synonym := lower(l_type_names(i));
      if substr(l_synonym, -2) = '_t' then
         l_synonym := substr(l_synonym, 1, length(l_synonym) - 2);
      elsif substr(l_synonym, -5) = '_type' then
         l_synonym := substr(l_synonym, 1, length(l_synonym) - 5);
      end if; 
      l_synonym := 'cwms_t_'||substr(l_synonym, 1, 25);
      for j in 1..9 loop
         begin
            select synonym_name 
              into l_existing
              from dba_synonyms
             where table_owner = '&cwms_schema'
               and synonym_name = l_synonym;
         exception
            when no_data_found then exit;
         end;
         l_synonym := substr(l_synonym, 1, length(l_synonym) - 2)||'_'||j; 
      end loop;
      begin
         execute immediate 'drop public synonym '||l_synonym;
      exception
         when others then null;
      end;
      l_sql := 'create public synonym '||l_synonym||' for &cwms_schema..'||l_type_names(i);
      dbms_output.put_line('-- '||l_sql);
      execute immediate l_sql;
   end loop;    
end;
/
*/