/* Formatted on 3/3/2011 8:05:07 AM (QP5 v5.163.1008.3004) */
SET DEFINE ON
@@defines.sql

CREATE OR REPLACE PACKAGE BODY cwms_sec_policy
AS
/******************************************************************************
   NAME:       cwms_sec_policy
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        1/3/2007             1. Created this package body.
******************************************************************************/
   FUNCTION read_ts_codes (ns IN VARCHAR2, na IN VARCHAR2)
      RETURN VARCHAR2
   IS
      l_predicate   VARCHAR2 (2000);
   BEGIN
      IF SYS_CONTEXT ('USERENV', 'SESSION_USER') = '&cwms_schema'
      THEN
         l_predicate := '1=1';
      ELSE
         l_predicate :=
            'ts_code in (select ts_code from mv_sec_ts_privileges where user_id =  SYS_CONTEXT(''USERENV'', ''SESSION_USER'')
                         and bitand(net_privilege_code, 4) = 4)';
      END IF;

      RETURN l_predicate;
   END;

   FUNCTION write_ts_codes (ns IN VARCHAR2, na IN VARCHAR2)
      RETURN VARCHAR2
   IS
      l_predicate   VARCHAR2 (2000);
   BEGIN
      IF SYS_CONTEXT ('USERENV', 'SESSION_USER') = '&cwms_schema'
      THEN
         l_predicate := '1=1';
      ELSE
         l_predicate :=
            'ts_code in (select ts_code from mv_sec_ts_privileges where user_id =  SYS_CONTEXT(''USERENV'', ''SESSION_USER'')
                         and bitand(net_privilege_code, 2) = 2)';
      END IF;

      RETURN l_predicate;
   END;
   
      FUNCTION da_role_office_codes (ns IN VARCHAR2, na IN VARCHAR2)
      RETURN VARCHAR2
   IS
      l_predicate   VARCHAR2 (2000);
   BEGIN
      IF SYS_CONTEXT ('USERENV', 'SESSION_USER') = '&cwms_schema'
      THEN
         l_predicate := '1=1';
      ELSE
         l_predicate :=                       
            'db_office_code in (SELECT db_office_code
                                 FROM at_sec_users 
                                 JOIN at_sec_locked_users 
                                USING (username, db_office_code)
                                WHERE is_locked = ''F'' 
                                  AND user_group_code = 3 
                                  AND username = cwms_util.get_user_id
                                )';
      END IF;

      RETURN l_predicate;
   END;

END cwms_sec_policy;
/