
    prompt
    accept echo_state  char prompt 'Enter ON or OFF for echo         : '
    accept inst        char prompt 'Enter the database SID           : '
    accept sys_passwd  char prompt 'Enter the password for SYS       : '
    accept cwms_passwd char prompt 'Enter the password for &cwms_schema   : '
    accept dbi_passwd  char prompt 'Enter the password for e1cwmsdbi : '
    
    accept test_passwd  char prompt 'Enter the password for e1hectest : '
    