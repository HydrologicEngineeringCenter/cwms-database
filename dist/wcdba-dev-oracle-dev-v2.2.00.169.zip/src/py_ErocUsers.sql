
    --
    -- ignore errors
    --
    whenever sqlerror continue
    
    drop user e1cwmspd;
    drop user e1cwmsdbi;
    
    --
    -- notice errors
    --
    whenever sqlerror exit sql.sqlcode
    
    variable dbi_passwd varchar2(50)
    exec :dbi_passwd := '&dbi_passwd';
    
    clear
    
    DECLARE
        dbi_passwd      VARCHAR2 (50) := :dbi_passwd;
        group_list      "&cwms_schema"."CHAR_32_ARRAY_TYPE" := "&cwms_schema"."CHAR_32_ARRAY_TYPE"('CWMS PD Users');
    BEGIN
        "&cwms_schema"."CWMS_SEC"."CREATE_CWMSDBI_DB_USER"('e1cwmsdbi', dbi_passwd, 'NAB');
    
        "&cwms_schema"."CWMS_SEC"."CREATE_USER" ('e1cwmspd', NULL, group_list, 'NAB');
        
        "&cwms_schema"."CWMS_SEC"."ASSIGN_TS_GROUP_USER_GROUP" ('All Rev TS IDs', 'Viewer Users', 'Read', 'NAB');
        
        "&cwms_schema"."CWMS_SEC"."ASSIGN_TS_GROUP_USER_GROUP" ('All TS IDs', 'CWMS Users', 'Read-Write', 'NAB');
    
    END;
    /
    
    --
    -- ignore errors
    --
    whenever sqlerror continue
    
    drop user e1hectest;
    drop user e1hectest_ro;
    drop user e1hectest_db;
    drop user e1hectest_ua;
    drop user e1hectest_dx;
    drop user e1hectest_da;
    drop user e1hectest_vt;
    drop user e1hectest_dv;
    drop user e1hectest_ccp_p;
    drop user e1hectest_ccp_m;
    drop user e1hectest_ccp_r;
    
    --
    -- notice errors
    --
    whenever sqlerror exit sql.sqlcode
    
    variable test_passwd varchar2(50)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
    exec :test_passwd := '&test_passwd';
    
    clear
    
    DECLARE
        test_passwd  VARCHAR2 (50) := :test_passwd;
        group_list   "&cwms_schema"."CHAR_32_ARRAY_TYPE";
    BEGIN
        -- hectest
        group_list := "&cwms_schema"."CHAR_32_ARRAY_TYPE" ('TS ID Creator', 'CWMS Users');
        "&cwms_schema"."CWMS_SEC"."CREATE_USER" ('e1hectest', test_passwd, group_list, 'NAB');
        --
        -- hectest_ro
        group_list := "&cwms_schema"."CHAR_32_ARRAY_TYPE" ('TS ID Creator', 'CWMS Users', 'Viewer Users');
        "&cwms_schema"."CWMS_SEC"."CREATE_USER" ('e1hectest_ro', test_passwd, group_list, 'NAB');
        --
        -- hectest_dba
        group_list := "&cwms_schema"."CHAR_32_ARRAY_TYPE" ('CWMS DBA Users');
        "&cwms_schema"."CWMS_SEC"."CREATE_USER" ('e1hectest_db', test_passwd, group_list, 'NAB');
        --
        -- hectest_ua
        group_list := "&cwms_schema"."CHAR_32_ARRAY_TYPE" ('CWMS User Admins', 'TS ID Creator', 'Viewer Users');
        "&cwms_schema"."CWMS_SEC"."CREATE_USER" ('e1hectest_ua', test_passwd, group_list, 'NAB');
        --
        -- hectest_dx
        group_list := "&cwms_schema"."CHAR_32_ARRAY_TYPE" ('Data Exchange Mgr', 'TS ID Creator', 'CWMS Users');
        "&cwms_schema"."CWMS_SEC"."CREATE_USER" ('e1hectest_dx', test_passwd, group_list, 'NAB');
        --
        -- hectest_da
        group_list := "&cwms_schema"."CHAR_32_ARRAY_TYPE" ('Data Acquisition Mgr', 'TS ID Creator', 'CWMS Users');
        "&cwms_schema"."CWMS_SEC"."CREATE_USER" ('e1hectest_da', test_passwd, group_list, 'NAB');
        --
        -- hectest_vt
        group_list := "&cwms_schema"."CHAR_32_ARRAY_TYPE" ('VT Mgr', 'TS ID Creator', 'CWMS Users');
        "&cwms_schema"."CWMS_SEC"."CREATE_USER" ('e1hectest_vt', test_passwd, group_list, 'NAB');
        --
        -- hectest_dv
        group_list := "&cwms_schema"."CHAR_32_ARRAY_TYPE" ('Data Acquisition Mgr', 'VT Mgr', 'TS ID Creator', 'CWMS Users');
        "&cwms_schema"."CWMS_SEC"."CREATE_USER" ('e1hectest_dv', test_passwd, group_list, 'NAB');
        --
        -- hectest_ccp_p
        group_list := "&cwms_schema"."CHAR_32_ARRAY_TYPE" ('CWMS PD Users', 'CCP Proc', 'TS ID Creator', 'CWMS Users');
        "&cwms_schema"."CWMS_SEC"."CREATE_USER" ('e1hectest_ccp_p', test_passwd, group_list, 'NAB');
        --
        -- hectest_ccp_m
        group_list := "&cwms_schema"."CHAR_32_ARRAY_TYPE" ('CWMS PD Users', 'CCP Mgr', 'TS ID Creator', 'CWMS Users');
        "&cwms_schema"."CWMS_SEC"."CREATE_USER" ('e1hectest_ccp_m', test_passwd, group_list, 'NAB');
        --
        -- hectest_ccp_r
        group_list := "&cwms_schema"."CHAR_32_ARRAY_TYPE" ('CWMS PD Users', 'CCP Reviewer', 'TS ID Creator', 'CWMS Users');
        "&cwms_schema"."CWMS_SEC"."CREATE_USER" ('e1hectest_ccp_r', test_passwd, group_list, 'NAB');
    
    END;
    /
    