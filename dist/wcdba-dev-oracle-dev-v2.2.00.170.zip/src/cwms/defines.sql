
define echo_state = ON
define inst = V11203CWMSDV
define cwms_schema = CWMS_20
