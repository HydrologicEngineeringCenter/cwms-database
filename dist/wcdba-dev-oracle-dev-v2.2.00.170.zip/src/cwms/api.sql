@@cwms_err_pkg
@@cwms_err_pkg_body

@@cwms_util_pkg
@@cwms_util_pkg_body

@@cwms_env_pkg
@@cwms_env_pkg_body

@@cwms_upass_pkg
@@cwms_upass_pkg_body

@@cwms/views/av_shef_decode_spec.sql

@@cwms_prop_pkg
@@cwms_prop_pkg_body

@@cwms_sec_policy
@@cwms_sec_policy_body

@@cwms_ts_pkg
@@cwms_ts_pkg_body

@@cwms_ts_id_pkg
@@cwms_ts_id_pkg_body

@@cwms_cat_pkg
@@cwms_cat_pkg_body

@@cwms_loc_pkg
@@cwms_loc_pkg_body

@@cwms_level_pkg
@@cwms_level_pkg_body

@@cwms_lookup_pkg
@@cwms_lookup_pkg_body

@@cwms_text_pkg
@@cwms_text_pkg_body

@@cwms_priv_pkg
@@cwms_priv_pkg_body

@@cwms_vt_pkg
@@cwms_vt_pkg_body

@@cwms_msg_pkg
@@cwms_msg_pkg_body

@@cwms_xchg_pkg
@@cwms_xchg_pkg_body

@@cwms_shef_pkg
@@cwms_shef_pkg_body

@@cwms_sec_pkg
@@cwms_sec_pkg_body

@@cwms_apex_pkg
@@cwms_apex_pkg_body

@@cwms_rounding_pkg
@@cwms_rounding_pkg_body

@@cwms_rating_pkg
@@cwms_rating_pkg_body

@@cwms_stream_pkg
@@cwms_stream_pkg_body

@@cwms_basin_pkg
@@cwms_basin_pkg_body

@@cwms_display_pkg
@@cwms_display_pkg_body

@@cwms_forecast_pkg
@@cwms_forecast_pkg_body

@@cwms_gage_pkg
@@cwms_gage_pkg_body

-- HOST pwd

@@cwms_project_pkg
@@cwms_project_pkg_body

@@cwms_lock_pkg
@@cwms_lock_pkg_body

@@cwms_embank_pkg
@@cwms_embank_pkg_body

@@cwms_water_supply_pkg
@@cwms_water_supply_pkg_body

@@cwms_outlet_pkg
@@cwms_outlet_pkg_body

@@cwms_turbine_pkg
@@cwms_turbine_pkg_body

@@cwms_schema_pkg
@@cwms_schema_pkg_body

@@cwms_alarm_pkg
@@cwms_alarm_pkg_body

