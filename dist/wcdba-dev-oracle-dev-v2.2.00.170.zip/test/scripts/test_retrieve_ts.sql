set serveroutput on;

declare
   l_tsinfo     cwms_20.timeseries_array := cwms_20.timeseries_array();
   l_tsdata     cwms_20.tsv_array        := cwms_20.tsv_array();
   
   l_tsid       varchar2(183)  := 'Test-storeTs.Flow.Inst.1Hour.0.test';
   l_units      varchar2(16)   := 'cfs';
   l_start_time date           := to_date('2006/02/01-00:15:00', 'yyyy/mm/dd-hh24:mi:ss'); 
   l_end_time   date           := to_date('2006/02/01-23:15:00', 'yyyy/mm/dd-hh24:mi:ss'); 
   l_cursor     sys_refcursor;
   l_cursor2    sys_refcursor;
   l_date_time  date;
   l_value      binary_double;
   l_quality    number;
   l_tsrequest  cwms_20.timeseries_req_array := cwms_20.timeseries_req_array();
   l_sequence   integer;
   i            pls_integer;
   l_ts_begin   timestamp;
   l_ts_end     timestamp;
   l_intvl      interval day to second;
   l_time_zone  varchar2(28);
   l_delete     boolean;
   l_store      boolean;
begin
   dbms_output.put_line('==>Creating data at ' || systimestamp);
   --
   -- create the data
   --
   l_date_time := l_start_time;
   i := 1;
   loop
      exit when l_date_time > l_end_time;
      if i < 4 or (i > 10 and i < 14) or i = 24then
         null;
      else
         l_tsdata.extend;
         l_tsdata(l_tsdata.last) := cwms_20.tsv_type(from_tz(l_date_time, 'UTC'), i, 0);
         if i > 20 then
            l_tsdata(l_tsdata.last).quality_code := 5;
         end if; 
      end if;
      i := i + 1;
      l_date_time := l_date_time + 1 / 24;
   end loop;
   l_tsinfo.extend(4);
   l_tsinfo(1) := cwms_20.timeseries_type('Tester-id1.Flow.Inst.0.0.test',     'kcfs', l_tsdata);
   l_tsinfo(2) := cwms_20.timeseries_type('Tester-id2.Flow.Inst.1Hour.0.test', 'kcfs', l_tsdata);
   l_tsinfo(3) := cwms_20.timeseries_type('Tester-id3.Flow.Inst.0.0.test',     'cms',  l_tsdata);
   l_tsinfo(4) := cwms_20.timeseries_type('Tester-id4.Flow.Inst.1Hour.0.test', 'cms',  l_tsdata);
   l_tsrequest.extend(l_tsinfo.count);
   
   for i in 1..l_tsinfo.count loop
      l_tsrequest(i) := cwms_20.timeseries_req_type(l_tsinfo(i).tsid, l_units, l_start_time, l_end_time);
   end loop;
   l_tsrequest(4).unit := null;
   --
   -- delete any existing data
   --
   l_delete := false;
   if l_delete then
      l_ts_begin := systimestamp;
      dbms_output.put_line('==>Starting delete at ' || l_ts_begin);
      for i in 1..l_tsinfo.count loop
         begin
            cwms_ts.delete_ts(l_tsinfo(i).tsid, cwms_util.delete_ts_cascade, 'NAB');
         exception
            when others then
               if instr(sqlerrm, 'TS_ID_NOT_FOUND') != 0 then
                  null;
               end if;
         end;
      end loop;
      l_ts_end := systimestamp;
      l_intvl  := l_ts_end - l_ts_begin; 
      dbms_output.put_line('==>Delete done at ' || l_ts_end || ' (' || l_intvl || ')');
   end if;
   --
   -- store the data
   --
   l_store := true;
   if l_store then
      l_ts_begin := systimestamp;
      dbms_output.put_line('==>Starting multi-store at ' || l_ts_begin);
      cwms_ts.store_ts_multi(l_tsinfo,cwms_util.delete_insert,'F',cwms_util.non_versioned,'NAB');
      commit;
      l_ts_end := systimestamp;
      l_intvl  := l_ts_end - l_ts_begin; 
      dbms_output.put_line('==>Multi-store done at ' || l_ts_end || ' (' || l_intvl || ')');
   end if;
   --
   -- retrieve the data in a loop
   --
   dbms_output.put_line(to_char(l_start_time, 'yyyy/mm/dd-hh24:mi:ss'));
   dbms_output.put_line(to_char(l_end_time,   'yyyy/mm/dd-hh24:mi:ss'));
   l_ts_begin := systimestamp;
   dbms_output.put_line('==>Starting retrieve loop at ' || l_ts_begin);
   for i in 1..l_tsinfo.count loop
      dbms_output.put_line('-----------------------------------------');
      dbms_output.put_line(l_tsinfo(i).tsid);
      cwms_ts.retrieve_ts(
         l_cursor,
         l_tsinfo(i).tsid,
         l_tsrequest(i).unit,
         l_start_time,
         l_end_time,
         'UTC', -- time zone
         'F',          -- trim
         'T',          -- start inclusive
         'T',          -- end inclusive
         'F',          -- previous
         'F',          -- next
          null,        -- version date
         'T',          -- max version
         'NAB');       -- office id
      loop
         fetch l_cursor into l_date_time, l_value, l_quality;
         exit when l_cursor%notfound;
         if l_value is null then
            dbms_output.put_line(
               '' 
               || nvl(to_char(l_date_time, 'yyyy/mm/dd-hh24:mi:ss'), ' <null> ')
               || ' <null> ' 
               || l_quality);
         else
            dbms_output.put_line(
               '' 
               || nvl(to_char(l_date_time, 'yyyy/mm/dd-hh24:mi:ss'), ' <null> ')
               || ' ' 
               || l_value
               || ' ' 
               || l_quality);
         end if;
      end loop;
      close l_cursor;
   end loop;
   l_ts_end := systimestamp;
   l_intvl  := l_ts_end - l_ts_begin; 
   dbms_output.put_line('==>Retrieve loop done at ' || l_ts_end || ' (' || l_intvl || ')');
   --
   -- retrieve the data with retrive_ts_multi
   --
   dbms_output.put_line('-----------------------------------------');
   l_ts_begin := systimestamp;
   dbms_output.put_line('==>Starting multi-retrieve at ' || l_ts_begin);
   cwms_ts.retrieve_ts_multi(
      l_cursor,
      l_tsrequest,
      'UTC', -- time zone
      'F',     -- trim
      'T',     -- start inclusive
      'T',     -- end inclusive
      'F',     -- previous
      'F',     -- next
      null,    -- version date
      'T',     -- max version
      'NAB');  -- office
   l_ts_end := systimestamp;
   l_intvl  := l_ts_end - l_ts_begin; 
   dbms_output.put_line('==>Multi-retrieve done at ' || l_ts_end || ' (' || l_intvl || ')');
   loop
      fetch l_cursor into l_sequence, l_tsid, l_units, l_start_time, l_end_time, l_time_zone, l_cursor2;
      exit when l_cursor%notfound;
      dbms_output.put_line( 
         ''  || l_sequence
             || ' ' || l_tsid 
             || ' ' || l_units
             || ' ' || to_char(l_start_time, 'yyyy/mm/dd-hh24:mi:ss')
             || ' ' || to_char(l_end_time, 'yyyy/mm/dd-hh24:mi:ss')
             || ' ' || l_time_zone);
      loop
         fetch l_cursor2 into l_date_time, l_value, l_quality;
         exit when l_cursor2%notfound;
         if l_value is null then
            dbms_output.put_line(
               chr(9) 
               || to_char(l_date_time, 'yyyy/mm/dd-hh24:mi:ss') 
               || ' <null> ' 
               || l_quality);
         else
            dbms_output.put_line(
               chr(9) 
               || to_char(l_date_time, 'yyyy/mm/dd-hh24:mi:ss') 
               || ' ' 
               || l_value
               || ' ' 
               || l_quality);
         end if;
      end loop;
      close l_cursor2;
   end loop;
   close l_cursor;
end;
/


