SET define on
@@defines.sql
---------------------------------
-- AT_ALARM_ID table.
-- 

CREATE TABLE AT_ALARM_ID
(
  ALARM_CODE      NUMBER                        NOT NULL,
  TS_NI_HASH      VARCHAR2(80 BYTE)             NOT NULL,
  DB_OFFICE_CODE  NUMBER                        NOT NULL,
  ALARM_ID        VARCHAR2(16 BYTE)             NOT NULL,
  ALARM_ID_DESC   VARCHAR2(128 BYTE)
)
TABLESPACE CWMS_20AT_DATA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING
/


CREATE UNIQUE INDEX AT_ALARM_ID_PK ON AT_ALARM_ID
(ALARM_CODE)
LOGGING
tablespace CWMS_20AT_DATA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL
/


CREATE UNIQUE INDEX AT_ALARM_ID_U01 ON AT_ALARM_ID
(ALARM_CODE, TS_NI_HASH)
LOGGING
tablespace CWMS_20AT_DATA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL
/


CREATE UNIQUE INDEX AT_ALARM_ID_U02 ON AT_ALARM_ID
(TS_NI_HASH, DB_OFFICE_CODE, ALARM_ID)
LOGGING
tablespace CWMS_20AT_DATA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL
/


ALTER TABLE AT_ALARM_ID ADD (
  CONSTRAINT AT_ALARM_ID_PK
 PRIMARY KEY
 (ALARM_CODE)
    USING INDEX 
    tablespace CWMS_20AT_DATA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ))
/

ALTER TABLE AT_ALARM_ID ADD (
  CONSTRAINT AT_ALARM_ID_U02
 UNIQUE (TS_NI_HASH, DB_OFFICE_CODE, ALARM_ID)
    USING INDEX 
    tablespace CWMS_20AT_DATA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ))
/

ALTER TABLE AT_ALARM_ID ADD (
  CONSTRAINT AT_ALARM_ID_U01
 UNIQUE (ALARM_CODE, TS_NI_HASH)
    USING INDEX 
    tablespace CWMS_20AT_DATA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ))
/

---------------------------------
-- AT_ALARM_CRITERIA table.
-- 
CREATE TABLE AT_ALARM_CRITERIA
(
  ALARM_CODE            NUMBER,
  ALARM_VALUE           NUMBER,
  SEASON_START_DAY      NUMBER,
  ASCENDING_DESCENDING  VARCHAR2(1 BYTE),
  ALARM_DESC            VARCHAR2(128 BYTE),
  ALARM_ACTION          VARCHAR2(16 BYTE),
  TRIP_RESET            VARCHAR2(1 BYTE)
)
tablespace CWMS_20AT_DATA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING
/


CREATE UNIQUE INDEX AT_ALARM_CRITERIA_PK ON AT_ALARM_CRITERIA
(ALARM_CODE, ALARM_VALUE, SEASON_START_DAY, ASCENDING_DESCENDING)
LOGGING
tablespace CWMS_20AT_DATA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL
/


ALTER TABLE AT_ALARM_CRITERIA ADD (
  CONSTRAINT AT_ALARM_CRITERIA_PK
 PRIMARY KEY
 (ALARM_CODE, ALARM_VALUE, SEASON_START_DAY, ASCENDING_DESCENDING)
    USING INDEX 
    tablespace CWMS_20AT_DATA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ))
/


ALTER TABLE AT_ALARM_CRITERIA ADD (
  CONSTRAINT AT_ALARM_CRITERIA_R01 
 FOREIGN KEY (ALARM_CODE) 
 REFERENCES AT_ALARM_ID (ALARM_CODE))
/
